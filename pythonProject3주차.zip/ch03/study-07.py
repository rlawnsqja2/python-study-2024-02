hong = {
    '이름': '홍길동',
    '나이': 20,
    '주소': '율도국'
}
print(hong)
lee = {
    0: '이순신',
    1: 30,
    2: '아산'
}
print(lee)
print(lee[0])
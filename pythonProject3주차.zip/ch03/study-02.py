numbers4 = [1,2,3,4]
numbers5 = numbers4

print('#' * 20)
print(numbers4)
print(numbers5)

numbers4.remove(3)

print('#' * 20)
print(numbers4)
print(numbers5)

my_book = 1, '파이썬', '미상', 2024
print( type(my_book))

my_book = (1, '파이썬 실습', '미상', 2024)
print(my_book)

my_book = []
print(type(my_book))
my_book.append('파이썬')
print(my_book)


# 내장함수(. print, type.....)

number1 = 1,2,3,4,5
number2 = (1,2,3,4,5)
number3 = (1,2,3,4)
number4 = [1,2,3,4]
print(number1)
print(number2)
print(number3)
print(number4)

print('=' * 40)
print('=' * 40)

print(type(number4))
print(len(number3))
print(len(number4))
for number in number4:
    print(number)
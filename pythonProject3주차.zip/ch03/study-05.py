for x in range(10):
    print(x)

data_list = [1,2,3,4]
for x in data_list:
    print(x)

str_data = 'abcdefg'

for x in str_data:
    print(x)
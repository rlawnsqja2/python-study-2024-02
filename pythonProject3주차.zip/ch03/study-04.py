numbers4 = ['a','b','c','d']
print('#' * 20)
print(numbers4)

numbers5 = numbers4[1:3]
print(numbers5)

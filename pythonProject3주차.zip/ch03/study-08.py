values = set()

print(values)

values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')
values.add('파이썬')

print('-' * 50)
print(values)

values.remove('파이썬')

print('-' * 50)
print(values)
